﻿using System.ComponentModel.DataAnnotations;
using System.Numerics;

namespace Taritas_Assesment.Models
{
    public class User
    {
        
        public int EmployeeId { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public bool IsAdmin { get; set; }

        public bool IsEntered { get; set; }

        public String Password { get; set; }




    }
}
