﻿using Microsoft.AspNetCore.Mvc;
using Taritas_Assesment.Models;

namespace Taritas_Assesment.Controllers
{
    public class UserController : Controller
    {
 
        private List<User> employees = new List<User>
    {
        new User { EmployeeId = 1, Name = "Rahul", Address = "Pune", IsAdmin = true, IsEntered = true, Password ="1234" },
        new User { EmployeeId = 2, Name = "Mayank", Address = "JabalPur", IsAdmin = false, IsEntered = false, Password ="4567"},
        new User { EmployeeId = 3, Name = "Piyush", Address = "Manendragarh", IsAdmin = false, IsEntered = false, Password ="6789" },
        new User { EmployeeId = 4, Name = "Ajit", Address = "Kolkata", IsAdmin = false, IsEntered = false, Password ="9087" },
        new User { EmployeeId = 5, Name = "Shristhi", Address = "Bangalore", IsAdmin = false, IsEntered = false, Password ="3456"},
        new User { EmployeeId = 6, Name = "Satish", Address = "Mumbai", IsAdmin = false, IsEntered = false, Password ="4567"},
        new User { EmployeeId = 7, Name = "Farid", Address = "Pune", IsAdmin = false, IsEntered = false, Password ="1111" },
        new User { EmployeeId = 8, Name = "Rupanshu", Address = "Bangalore", IsAdmin = false, IsEntered = false, Password ="2222"},
        new User { EmployeeId = 9, Name = "Raman", Address = "JabalPur", IsAdmin = false, IsEntered = false, Password ="2233" },
        new User { EmployeeId = 10, Name = "Dheeraj", Address = "JabalPur", IsAdmin = false, IsEntered = false, Password ="5643" },
    };

        public ActionResult Index()
        {
            return View(employees);
        }

        public ActionResult Edit(int id)
        {
            User employee = employees.FirstOrDefault(e => e.EmployeeId == id);



            return View(employee);
        }

        public ActionResult GetPassword(int employeeId)
        {
            // Retrieve the password for the selected employee from your data source
            string password = employees[employeeId].Password;
            return Json(password);
        }

    }

}

